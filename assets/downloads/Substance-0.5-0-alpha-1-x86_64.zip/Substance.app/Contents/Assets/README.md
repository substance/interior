# Substance

Substance is an open platform for collaborative composition and sharing of digital documents. Substance is free to use and Open Source from tip to toe.

For docs see: http://interior.substance.io/modules/substance.html

For an early demo see: http://interior.substance.io/substance/

To suggest a feature, report a bug, or general discussion: http://github.com/substance/substance/issues/